
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ContactForm from './components/ContactForm';
import Dashboard from './components/Dashboard';
import Booking from './components/Booking';
import AccessibilityStatement from './components/AccessibilityStatement';
import About from './components/About';
import FAQ from './components/FAQ';

const App: React.FC = () => {
  const [view, setView] = useState<'home' | 'booking' | 'dashboard' | 'accessibility'>('home');
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallGuide, setShowInstallGuide] = useState(false);

  useEffect(() => {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });
  }, []);

  const handleInstallClick = () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      deferredPrompt.userChoice.then((choiceResult: any) => {
        if (choiceResult.outcome === 'accepted') {
          console.log('User accepted the install prompt');
        }
        setDeferredPrompt(null);
      });
    } else {
      setShowInstallGuide(true);
    }
  };

  const renderView = () => {
    switch(view) {
      case 'dashboard':
        return <Dashboard />;
      case 'booking':
        return <Booking />;
      case 'accessibility':
        return <AccessibilityStatement />;
      default:
        return (
          <>
            <Hero />
            <About />
            <section id="services" className="py-24 bg-slate-50">
              <div className="max-w-7xl mx-auto px-4">
                <div className="text-center mb-16">
                  <h2 className="text-4xl font-bold serif mb-4">תחומי התמחות המשרד</h2>
                  <p className="text-slate-500 max-w-xl mx-auto mb-6">משרדנו מלווה נפגעים מול חברות הביטוח והמוסדות השונים במקצועיות חסרת פשרות.</p>
                  <div className="w-24 h-1 bg-amber-500 mx-auto"></div>
                </div>
                <div className="grid md:grid-cols-3 gap-8">
                  <div className="p-8 border border-slate-100 rounded-2xl shadow-sm hover:shadow-xl transition-all group bg-white">
                    <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">🚑</div>
                    <h3 className="text-xl font-bold mb-3">נזקי גוף ותאונות דרכים</h3>
                    <p className="text-slate-600">ייצוג נפגעי תאונות דרכים ותאונות קשות מול חברות הביטוח לקבלת פיצוי הולם.</p>
                  </div>
                  <div className="p-8 border border-slate-100 rounded-2xl shadow-sm hover:shadow-xl transition-all group bg-white">
                    <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">🏗️</div>
                    <h3 className="text-xl font-bold mb-3">תאונות עבודה וביטוח לאומי</h3>
                    <p className="text-slate-600">ליווי וייצוג בוועדות רפואיות של המוסד לביטוח לאומי ובתביעות מול מעסיקים.</p>
                  </div>
                  <div className="p-8 border border-slate-100 rounded-2xl shadow-sm hover:shadow-xl transition-all group bg-white">
                    <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">🎒</div>
                    <h3 className="text-xl font-bold mb-3">תאונות תלמידים</h3>
                    <p className="text-slate-600">מיצוי זכויות תלמידים שנפגעו במסגרת מוסדות חינוך או פעילות חוץ-בית ספרית.</p>
                  </div>
                  <div className="p-8 border border-slate-100 rounded-2xl shadow-sm hover:shadow-xl transition-all group bg-white">
                    <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">📜</div>
                    <h3 className="text-xl font-bold mb-3">שירותי נוטריון</h3>
                    <p className="text-slate-600">מתן כלל אישורי הנוטריון הנדרשים במהירות וביעילות, כולל אימות חתימה ותרגומים.</p>
                  </div>
                  <div className="p-8 border border-slate-100 rounded-2xl shadow-sm hover:shadow-xl transition-all group bg-white">
                    <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">☂️</div>
                    <h3 className="text-xl font-bold mb-3">תביעות ביטוח</h3>
                    <p className="text-slate-600">ניהול תביעות מול חברות ביטוח בגין פוליסות חיים, בריאות, סיעוד ואובדן כושר עבודה.</p>
                  </div>
                  <div className="p-8 border border-slate-100 rounded-2xl shadow-sm hover:shadow-xl transition-all group bg-white">
                    <div className="text-4xl mb-4 group-hover:scale-110 transition-transform">🏥</div>
                    <h3 className="text-xl font-bold mb-3">רשלנות רפואית</h3>
                    <p className="text-slate-600">בדיקה וניהול תיקי רשלנות רפואית מורכבים בשיתוף עם מומחים רפואיים מובילים.</p>
                  </div>
                </div>
              </div>
            </section>
            
            <FAQ />

            <section className="py-24 bg-white" id="contact">
               <div className="max-w-7xl mx-auto px-4 text-center mb-12">
                  <h2 className="text-4xl font-bold serif mb-4">פנייה ישירה לעו"ד דביר אייזן</h2>
                  <p className="text-slate-600">הודעתכם תועבר מיידית לנייד האישי שלי לקבלת מענה מהיר</p>
                </div>
              <ContactForm />
            </section>
          </>
        );
    }
  };

  return (
    <div className="min-h-screen pt-20 flex flex-col">
      <Navbar onNavigate={setView} activeView={view} onInstall={handleInstallClick} />
      <main className="flex-grow">
        {renderView()}
      </main>

      {showInstallGuide && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setShowInstallGuide(false)}>
          <div className="bg-white rounded-2xl p-8 max-w-sm w-full shadow-2xl text-center" onClick={e => e.stopPropagation()}>
            <div className="text-5xl mb-4 text-amber-500">📱</div>
            <h3 className="text-2xl font-bold mb-4 serif">הורדת האפליקציה לנייד</h3>
            <div className="space-y-4 text-right text-slate-600">
              <p className="font-bold text-slate-900 underline">באייפון (Safari):</p>
              <p>1. לחץ על כפתור ה-<strong>Share</strong> (ריבוע עם חץ למעלה).</p>
              <p>2. גלול מטה ובחר ב-<strong>"Add to Home Screen"</strong> (הוסף למסך הבית).</p>
              <p className="font-bold text-slate-900 underline mt-4">באנדרואיד (Chrome):</p>
              <p>לחץ על שלוש הנקודות למעלה ובחר ב-<strong>"Install app"</strong>.</p>
            </div>
            <button 
              onClick={() => setShowInstallGuide(false)}
              className="mt-8 w-full bg-slate-900 text-white py-3 rounded-xl font-bold"
            >
              הבנתי, תודה
            </button>
          </div>
        </div>
      )}
      
      <footer className="bg-slate-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-amber-500 rounded flex items-center justify-center">
                  <span className="text-slate-900 font-bold">DA</span>
                </div>
                <h3 className="text-2xl font-bold serif">דביר אייזן - משרד עורכי דין</h3>
              </div>
              <p className="text-slate-400 max-w-md leading-relaxed">
                משרדנו חרט על דגלו מצוינות מקצועית ויחס אישי. אנו מתמחים בתביעות נזיקין וביטוח ומלווים כל לקוח עד למיצוי מלא של זכויותיו.
              </p>
            </div>
            <div>
              <h4 className="text-amber-500 font-bold mb-4">יצירת קשר</h4>
              <ul className="space-y-2 text-slate-300">
                <li>טל': 03-7446799</li>
                <li>פקס: 03-7446798</li>
                <li>נייד: 052-2573832</li>
                <li>דוא"ל: dvirgold@zahav.net.il</li>
              </ul>
            </div>
            <div>
              <h4 className="text-amber-500 font-bold mb-4">כתובת המשרד</h4>
              <p className="text-slate-300">
                יעל רום 4, פתח תקווה
              </p>
              <div className="mt-6 flex flex-col gap-2">
                <button 
                  onClick={() => setView('accessibility')}
                  className="text-sm text-amber-500 hover:text-amber-400 underline font-semibold transition-colors flex items-center gap-2"
                >
                  ♿ הצהרת נגישות
                </button>
              </div>
            </div>
          </div>
          <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-500 text-sm">כל הזכויות שמורות © 2024 דביר אייזן - משרד עורכי דין ונוטריון</p>
            <div className="flex gap-6">
              <a href="#" className="text-slate-400 hover:text-amber-500 transition-colors">פייסבוק</a>
              <a href="#" className="text-slate-400 hover:text-amber-500 transition-colors">לינקדאין</a>
              <a href={`https://wa.me/972522573832`} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-amber-500 transition-colors font-bold">WhatsApp</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
