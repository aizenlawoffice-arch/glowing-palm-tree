
import { GoogleGenAI, Type } from "@google/genai";

const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const analyzeInquiry = async (message: string) => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `נא לנתח את פניית הלקוח הבאה ולספק סיכום קצר, הערכת דחיפות (נמוכה/בינונית/גבוהה) ותחום משפטי רלוונטי: "${message}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.STRING, description: "Short summary in Hebrew" },
            urgency: { type: Type.STRING, description: "Urgency level" },
            category: { type: Type.STRING, description: "Legal category" }
          },
          required: ["summary", "urgency", "category"]
        }
      }
    });

    return response.text;
  } catch (error) {
    console.error("AI Analysis failed:", error);
    return JSON.stringify({ summary: "ניתוח נכשל", urgency: "לא ידוע", category: "כללי" });
  }
};
