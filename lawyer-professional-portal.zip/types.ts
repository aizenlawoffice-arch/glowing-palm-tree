
export interface Inquiry {
  id: string;
  name: string;
  phone: string;
  email: string;
  message: string;
  timestamp: number;
  aiAnalysis?: string;
  status: 'new' | 'contacted' | 'resolved';
}

export interface Appointment {
  id: string;
  clientName: string;
  date: string;
  time: string;
  type: string;
  notes: string;
}

export enum LegalArea {
  TORTS = 'נזיקין',
  INSURANCE = 'ביטוח',
  WORK_ACCIDENTS = 'תאונות עבודה',
  TRAFFIC = 'תעבורה',
  NOTARY = 'נוטריון',
  LITIGATION = 'ליטיגציה'
}
