
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          {/* Side Image/Stat Box */}
          <div className="lg:w-1/3 w-full">
            <div className="relative">
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl"></div>
              <div className="relative bg-slate-900 rounded-2xl p-8 text-white shadow-2xl border-b-4 border-amber-500">
                <div className="text-5xl font-bold text-amber-500 mb-2 serif">20+</div>
                <div className="text-xl font-bold mb-4">שנות ניסיון ומוניטין</div>
                <p className="text-slate-400 text-sm leading-relaxed">
                  עו"ד דביר אייזן פועל מעל שני עשורים בזירה המשפטית בישראל, עם התמחות עמוקה ומוכחת בדיני נזיקין וביטוח.
                </p>
                <div className="mt-8 pt-8 border-t border-slate-800">
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-amber-500 text-xl">⚖️</span>
                    <span className="text-sm font-medium">ייצוג בכל ערכאות השיפוט</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-amber-500 text-xl">👤</span>
                    <span className="text-sm font-medium">יחס אישי וליווי צמוד</span>
                  </div>
                </div>
              </div>
              <div className="mt-6 p-4 bg-amber-50 border border-amber-100 rounded-xl text-amber-900 text-sm font-medium text-center italic">
                "שואפים למצוינות בכל, ללא פשרות"
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:w-2/3 w-full">
            <h2 className="text-4xl font-bold serif mb-6 text-slate-900 relative inline-block">
              אודות המשרד
              <div className="absolute -bottom-2 right-0 w-2/3 h-1 bg-amber-500"></div>
            </h2>
            
            <div className="space-y-6 text-lg text-slate-700 leading-relaxed">
              <p className="font-bold text-xl text-slate-900">
                עו"ד דביר אייזן, מתמחה בתחום הנזיקין והביטוח במתן ייעוץ וייצוג בכל ערכאות השיפוט בישראל. המשרד פועל מעל 20 שנה בארץ וצבר ניסיון רב ערך בניהול תיקים מורכבים.
              </p>
              
              <p>
                בין יתר הנושאים השונים ניתן למצוא במשרדנו מומחיות מיוחדת בתחום הביטוח והנזיקין. עו"ד דביר אייזן מטפל במגוון רחב של תחומים הכוללים: 
                <span className="text-slate-900 font-semibold"> דיני נזיקין, תאונות עבודה, ביטוח חיים, ביטוחי חבות, ביטוחי רכום, תאונות דרכים, תביעות ביטוח לאומי, תעבורה, ותביעות פיצויים עבור נזקי רכוש וממון.</span>
              </p>

              <div className="bg-slate-50 p-6 rounded-xl border-r-4 border-slate-900 my-8">
                <h3 className="text-xl font-bold mb-3 text-slate-900">מחלקת הליטיגציה - חוד החנית של המשרד</h3>
                <p>
                  אנו מאמינים כי נושא הליטיגציה (ייצוג בבית המשפט) הינו קריטי למתן שירות משפטי מנצח. 
                  עו"ד דביר אייזן מנהל תיקים רבים באופן אישי, מופיע בבתי המשפט ומייצג בנחישות בכל ערכאות השיפוט בישראל. 
                  הניסיון שנצבר באלפי שעות בית משפט מאפשר לנו להעניק יתרון אסטרטגי לכל לקוח.
                </p>
              </div>

              <p>
                משרדנו חרט על דגלו חתירה למצוינות, תוך הענקת שירות וטיפול מקצועי ללא כל פשרות. 
                במקביל, אנו מקפידים לשמור על קשר אישי ישיר עם כל לקוח ולקוח בהתאם לצרכיו הייחודיים. 
                כל פנייה למשרד זוכה למוניטין והניסיון הרב שצברנו לאורך השנים.
              </p>

              <p className="text-amber-600 font-bold italic">
                נשמח לראות גם אתכם ברשימת הלקוחות שלנו ולהעניק לכם את המעטפת המקצועית של מחלקת הליטיגציה והשירותים המשפטיים של משרדנו.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
