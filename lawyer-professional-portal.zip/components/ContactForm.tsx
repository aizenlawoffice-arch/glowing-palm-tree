
import React, { useState } from 'react';
import { analyzeInquiry } from '../services/geminiService';
import { Inquiry } from '../types';

const ContactForm: React.FC = () => {
  const [formData, setFormData] = useState({ name: '', phone: '', email: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Simulate API analysis
      const analysisRaw = await analyzeInquiry(formData.message);
      
      const newInquiry: Inquiry = {
        id: Math.random().toString(36).substr(2, 9),
        ...formData,
        timestamp: Date.now(),
        aiAnalysis: analysisRaw,
        status: 'new'
      };

      // Store in local storage to simulate backend
      const existing = JSON.parse(localStorage.getItem('inquiries') || '[]');
      localStorage.setItem('inquiries', JSON.stringify([...existing, newInquiry]));

      setSuccess(true);
      setFormData({ name: '', phone: '', email: '', message: '' });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
      setTimeout(() => setSuccess(false), 5000);
    }
  };

  return (
    <div id="contact" className="max-w-5xl mx-auto bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-100">
      <div className="grid md:grid-cols-2">
        <div className="p-8 md:p-12 bg-slate-900 text-white">
          <h2 className="text-3xl font-bold mb-6 serif">צרו קשר ישיר</h2>
          <p className="text-slate-400 mb-8">
            השאירו פרטים וההודעה שלכם תועבר ישירות לנייד האישי של עו"ד דביר אייזן. אנחנו מבטיחים לחזור אליכם בהקדם האפשרי.
          </p>
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-500/20 text-amber-500 flex items-center justify-center rounded-full shrink-0">📍</div>
              <div>
                <p className="text-sm text-slate-500">כתובת המשרד</p>
                <p className="font-semibold">יעל רום 4, פתח תקווה</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-500/20 text-amber-500 flex items-center justify-center rounded-full shrink-0">📱</div>
              <div>
                <p className="text-sm text-slate-500">נייד (ישיר)</p>
                <p className="font-semibold">052-2573832</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-500/20 text-amber-500 flex items-center justify-center rounded-full shrink-0">📞</div>
              <div>
                <p className="text-sm text-slate-500">טלפון המשרד</p>
                <p className="font-semibold">03-7446799</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-500/20 text-amber-500 flex items-center justify-center rounded-full shrink-0">📠</div>
              <div>
                <p className="text-sm text-slate-500">פקס</p>
                <p className="font-semibold">03-7446798</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-500/20 text-amber-500 flex items-center justify-center rounded-full shrink-0">✉️</div>
              <div>
                <p className="text-sm text-slate-500">דואר אלקטרוני</p>
                <p className="font-semibold">dvirgold@zahav.net.il</p>
              </div>
            </div>
          </div>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8 md:p-12 space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">שם מלא</label>
            <input 
              required
              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-amber-500 outline-none transition-all"
              type="text" 
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
              placeholder="ישראל ישראלי"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">טלפון</label>
              <input 
                required
                className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-amber-500 outline-none transition-all"
                type="tel" 
                value={formData.phone}
                onChange={e => setFormData({...formData, phone: e.target.value})}
                placeholder="05X-XXXXXXX"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">אימייל</label>
              <input 
                className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-amber-500 outline-none transition-all"
                type="email" 
                value={formData.email}
                onChange={e => setFormData({...formData, email: e.target.value})}
                placeholder="name@example.com"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">תוכן הפנייה</label>
            <textarea 
              required
              rows={4}
              className="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-amber-500 outline-none transition-all"
              value={formData.message}
              onChange={e => setFormData({...formData, message: e.target.value})}
              placeholder="פרטו בקצרה על המקרה (נזקי גוף, תאונת דרכים וכו')..."
            />
          </div>
          <button 
            disabled={loading}
            className={`w-full py-4 rounded-lg font-bold text-white transition-all transform active:scale-95 ${loading ? 'bg-slate-400' : 'bg-slate-900 hover:bg-slate-800 shadow-lg shadow-slate-200'}`}
          >
            {loading ? 'מעבד פנייה דחופה...' : 'שלח הודעה ישירה לנייד'}
          </button>
          
          {success && (
            <div className="p-4 bg-emerald-50 text-emerald-700 rounded-lg text-center font-medium border border-emerald-100 animate-pulse">
              הודעתך נשלחה בהצלחה! עו"ד דביר אייזן יחזור אליך בהקדם.
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default ContactForm;
