
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-24 overflow-hidden bg-slate-900">
      <div className="absolute inset-0 opacity-10 bg-[url('https://images.unsplash.com/photo-1589829545856-d10d557cf95f?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center"></div>
      <div className="max-w-7xl mx-auto px-4 relative z-10 text-center">
        <div className="inline-block bg-amber-500/10 text-amber-500 px-6 py-2 rounded-full text-sm font-bold mb-8 border border-amber-500/20 tracking-wide">
          מעל 20 שנות ניסיון בליטיגציה ודיני נזיקין
        </div>
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-8 leading-tight serif">
          דביר אייזן - משרד עורכי דין<br />
          <span className="text-amber-500">מומחיות בנזיקין וביטוח</span>
        </h1>
        <p className="text-xl text-slate-300 max-w-2xl mx-auto mb-12 leading-relaxed">
          משרדנו מספק ייצוג משפטי נחוש ומקצועי בכל ערכאות השיפוט בישראל. אנחנו כאן כדי להילחם על הזכויות שלכם מול חברות הביטוח והמוסד לביטוח לאומי.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-5">
          <button 
            onClick={() => {
              document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="w-full sm:w-auto px-10 py-5 bg-amber-500 hover:bg-amber-400 text-slate-900 font-bold rounded-xl transition-all transform hover:scale-105 shadow-2xl shadow-amber-500/20"
          >
            פנייה ישירה לעו"ד דביר אייזן
          </button>
          <button 
            onClick={() => {
              document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="w-full sm:w-auto px-10 py-5 bg-white/5 hover:bg-white/10 text-white border border-white/10 font-bold rounded-xl backdrop-blur-sm transition-all"
          >
            מידע נוסף אודות המשרד
          </button>
        </div>
        
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-1">20+</div>
            <div className="text-slate-400 text-sm">שנות ניסיון</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-1">1000+</div>
            <div className="text-slate-400 text-sm">תיקים שנוהלו</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-1">95%</div>
            <div className="text-slate-400 text-sm">הצלחה בהסדרים</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-white mb-1">24/7</div>
            <div className="text-slate-400 text-sm">מענה לפנייה</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
