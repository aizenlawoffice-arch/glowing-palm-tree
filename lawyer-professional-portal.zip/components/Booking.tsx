
import React, { useState } from 'react';
import { Appointment } from '../types';

const Booking: React.FC = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    date: '',
    time: '',
    type: 'ייעוץ ראשוני - נזקי גוף',
    notes: ''
  });

  const timeSlots = ["09:00", "10:00", "11:00", "13:00", "14:00", "15:00", "16:00"];

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    const newApp: Appointment = {
      id: Math.random().toString(36).substr(2, 9),
      clientName: formData.name,
      date: formData.date,
      time: formData.time,
      type: formData.type,
      notes: formData.notes
    };

    const existing = JSON.parse(localStorage.getItem('appointments') || '[]');
    localStorage.setItem('appointments', JSON.stringify([...existing, newApp]));
    setStep(3);
  };

  return (
    <div className="max-w-2xl mx-auto py-20 px-4">
      <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-100">
        {step === 1 && (
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-6 serif">קביעת פגישת ייעוץ</h2>
            <p className="text-slate-600 mb-8">אנא בחרו את התאריך והשעה הנוחים לכם.</p>
            <div className="grid gap-6">
              <div>
                <label className="block text-right mb-2 font-medium">תאריך</label>
                <input 
                  type="date" 
                  className="w-full p-4 border rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                  min={new Date().toISOString().split('T')[0]}
                  onChange={e => setFormData({...formData, date: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-4 gap-2">
                {timeSlots.map(t => (
                  <button
                    key={t}
                    onClick={() => setFormData({...formData, time: t})}
                    className={`p-3 rounded-lg border text-sm font-bold transition-all ${formData.time === t ? 'bg-amber-500 border-amber-500 text-white' : 'hover:border-amber-500'}`}
                  >
                    {t}
                  </button>
                ))}
              </div>
              <button 
                disabled={!formData.date || !formData.time}
                onClick={() => setStep(2)}
                className="mt-4 bg-slate-900 text-white py-4 rounded-xl font-bold hover:bg-slate-800 disabled:opacity-50"
              >
                המשך להזנת פרטים
              </button>
            </div>
          </div>
        )}

        {step === 2 && (
          <form onSubmit={handleBooking} className="space-y-6 text-right">
            <h2 className="text-2xl font-bold mb-4 serif text-center">פרטי הקשר שלכם</h2>
            <div>
              <label className="block mb-1 text-slate-700 font-medium">שם מלא</label>
              <input 
                required
                placeholder="הזינו שם מלא"
                className="w-full p-4 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div>
              <label className="block mb-1 text-slate-700 font-medium">נושא הפגישה</label>
              <select 
                className="w-full p-4 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                value={formData.type}
                onChange={e => setFormData({...formData, type: e.target.value})}
              >
                <option>תאונת דרכים / נזקי גוף</option>
                <option>תאונת עבודה וביטוח לאומי</option>
                <option>תאונת תלמידים</option>
                <option>תביעת פוליסת ביטוח</option>
                <option>שירות נוטריוני</option>
              </select>
            </div>
            <div>
              <label className="block mb-1 text-slate-700 font-medium">תיאור קצר של המקרה (אופציונלי)</label>
              <textarea 
                rows={3}
                placeholder="ספרו לנו בקצרה על המקרה..."
                className="w-full p-4 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none"
                value={formData.notes}
                onChange={e => setFormData({...formData, notes: e.target.value})}
              />
            </div>
            <div className="flex gap-4">
               <button 
                type="button"
                onClick={() => setStep(1)}
                className="w-1/3 border py-4 rounded-xl font-bold hover:bg-slate-50 transition-colors"
              >
                חזרה
              </button>
              <button 
                type="submit"
                className="w-2/3 bg-amber-500 text-slate-900 py-4 rounded-xl font-bold shadow-lg hover:bg-amber-400 transition-all"
              >
                אשר פגישה במשרד
              </button>
            </div>
          </form>
        )}

        {step === 3 && (
          <div className="text-center py-10">
            <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center text-4xl mx-auto mb-6">✓</div>
            <h2 className="text-3xl font-bold mb-4 serif">הפגישה נקבעה בהצלחה!</h2>
            <p className="text-slate-600 mb-8 leading-relaxed">
              פרטי הפגישה נשלחו למשרדנו ליום {formData.date} בשעה {formData.time}.
              <br />
              עו"ד דביר אייזן או צוות המשרד יצרו עמכם קשר לווידוא סופי.
            </p>
            <button 
              onClick={() => window.location.reload()}
              className="bg-slate-900 text-white px-8 py-3 rounded-xl font-bold hover:bg-slate-800 transition-colors"
            >
              חזרה לדף הבית
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Booking;
