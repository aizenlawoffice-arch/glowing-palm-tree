
import React from 'react';

interface NavbarProps {
  onNavigate: (view: 'home' | 'booking' | 'dashboard') => void;
  activeView: string;
  onInstall?: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, activeView, onInstall }) => {
  const scrollIntoView = (id: string) => {
    if (activeView !== 'home') {
      onNavigate('home');
      setTimeout(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md border-b border-slate-200 z-50">
      <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
        <div className="flex items-center gap-4 cursor-pointer" onClick={() => onNavigate('home')}>
          <div className="flex items-center">
            <img 
              src="logo.png" 
              alt="דביר אייזן לוגו" 
              className="h-12 md:h-14 w-auto object-contain"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                e.currentTarget.parentElement?.querySelector('.fallback-icon')?.classList.remove('hidden');
              }}
            />
            <div className="fallback-icon hidden w-10 h-10 bg-slate-900 flex items-center justify-center rounded-lg shadow-lg">
              <span className="text-amber-500 font-bold text-xl">DA</span>
            </div>
          </div>
          <div className="flex flex-col leading-tight border-r border-slate-200 pr-4 mr-2 hidden sm:flex">
            <span className="text-xl font-bold tracking-tight text-slate-900 serif">דביר אייזן</span>
            <span className="text-xs text-slate-500 font-medium">משרד עורכי דין ונוטריון</span>
          </div>
        </div>
        
        <div className="hidden md:flex items-center gap-6 font-medium">
          <button 
            onClick={() => onNavigate('home')}
            className={`${activeView === 'home' ? 'text-amber-600' : 'text-slate-600 hover:text-slate-900'} transition-colors`}
          >
            דף הבית
          </button>
          <button 
            onClick={() => scrollIntoView('about')}
            className="text-slate-600 hover:text-slate-900 transition-colors"
          >
            אודות
          </button>
          <button 
            onClick={() => scrollIntoView('services')}
            className="text-slate-600 hover:text-slate-900 transition-colors"
          >
            התמחויות
          </button>
          <button 
            onClick={() => scrollIntoView('faq')}
            className="text-slate-600 hover:text-slate-900 transition-colors"
          >
            שאלות ותשובות
          </button>
          <button 
            onClick={() => onNavigate('booking')}
            className={`${activeView === 'booking' ? 'text-amber-600' : 'text-slate-600 hover:text-slate-900'} transition-colors`}
          >
            קביעת פגישה
          </button>
          <button 
            onClick={() => onNavigate('dashboard')}
            className={`${activeView === 'dashboard' ? 'text-amber-600 border-b-2 border-amber-600' : 'text-slate-600 hover:text-slate-900'}`}
          >
            ניהול
          </button>
        </div>

        <div className="flex items-center gap-3">
          <button 
            onClick={onInstall}
            className="hidden sm:flex items-center gap-2 text-xs font-bold text-slate-700 bg-slate-100 px-3 py-2 rounded-lg hover:bg-slate-200 transition-all"
            title="הורדת האתר כאפליקציה"
          >
            <span className="text-lg">📱</span>
            הורד אפליקציה
          </button>
          <button 
            onClick={() => onNavigate('booking')}
            className="bg-slate-900 text-white px-6 py-2 rounded-full font-semibold hover:bg-slate-800 transition-all shadow-md active:scale-95"
          >
            ייעוץ משפטי
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
