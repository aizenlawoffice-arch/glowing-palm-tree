
import React from 'react';

const AccessibilityStatement: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto py-20 px-6">
      <h1 className="text-4xl font-bold serif mb-8 border-b-2 border-amber-500 pb-2">הצהרת נגישות</h1>
      
      <div className="prose prose-slate max-w-none space-y-6 text-slate-700 leading-relaxed text-right">
        <section>
          <h2 className="text-2xl font-bold serif text-slate-900">מבוא</h2>
          <p>
            אנו בדביר אייזן - משרד עורכי דין ונוטריון, רואים חשיבות עליונה בהנגשת שירותינו לכלל הציבור, לרבות לאנשים עם מוגבלות. 
            השקענו משאבים רבים בביצוע התאמות נגישות באתר האינטרנט שלנו על מנת לאפשר חווית גלישה נוחה ופשוטה לכולם.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold serif text-slate-900">סטטוס נגישות</h2>
          <p>
            אתר זה עומד בדרישות תקנות שוויון זכויות לאנשים עם מוגבלות (התאמות נגישות לשירות), התשע"ג 2013. 
            התאמות הנגישות בוצעו עפ"י המלצות התקן הישראלי (ת"י 5568) לנגישות תכנים באינטרנט ברמת AA ובהתאם למסמך WCAG2.1 הבינלאומי.
          </p>
        </section>

        <section>
          <h2 className="text-2xl font-bold serif text-slate-900">התאמות עיקריות שבוצעו</h2>
          <ul className="list-disc list-inside space-y-2 pr-4">
            <li>תמיכה בניווט באמצעות המקלדת (שימוש במקש TAB).</li>
            <li>שימוש בתגיות סמנטיות (HTML5) למבנה אתר תקני.</li>
            <li>ניגודיות צבעים הולמת לעמידה בדרישות הקריאות.</li>
            <li>הוספת טקסט חלופי (Alt Text) לתמונות משמעותיות.</li>
            <li>התאמה מלאה לצפייה במכשירים ניידים (רספונסיביות).</li>
            <li>טפסים נגישים הכוללים תוויות ברורות.</li>
          </ul>
        </section>

        <section className="bg-slate-100 p-6 rounded-xl border-r-4 border-amber-500">
          <h2 className="text-2xl font-bold serif text-slate-900 mb-4">יצירת קשר בנושא נגישות</h2>
          <p className="mb-4">
            אנו עושים מאמצים רבים להנגיש את כלל חלקי האתר. אם נתקלתם בקושי בגלישה או במידע שאינו נגיש כראוי, נשמח אם תעדכנו אותנו כדי שנוכל לתקן את הליקוי בהקדם.
          </p>
          <div className="font-semibold text-slate-900">
            <p>רכז נגישות: עו"ד דביר אייזן</p>
            <p>טלפון: 03-7446799</p>
            <p>נייד: 052-2573832</p>
            <p>דוא"ל: <a href="mailto:dvirgold@zahav.net.il" className="text-amber-600 underline">dvirgold@zahav.net.il</a></p>
            <p>כתובת: יעל רום 4, פתח תקווה</p>
          </div>
        </section>

        <p className="text-sm text-slate-400 pt-8">עדכון אחרון להצהרה: פברואר 2024</p>
      </div>
    </div>
  );
};

export default AccessibilityStatement;
