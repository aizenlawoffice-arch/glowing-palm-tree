
import React, { useState, useEffect } from 'react';
import { Inquiry, Appointment } from '../types';

const Dashboard: React.FC = () => {
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [filter, setFilter] = useState<'all' | 'new'>('all');

  useEffect(() => {
    const loadData = () => {
      const storedInquiries = JSON.parse(localStorage.getItem('inquiries') || '[]');
      const storedAppointments = JSON.parse(localStorage.getItem('appointments') || '[]');
      setInquiries(storedInquiries.sort((a: any, b: any) => b.timestamp - a.timestamp));
      setAppointments(storedAppointments);
    };
    loadData();
    const interval = setInterval(loadData, 5000); 
    return () => clearInterval(interval);
  }, []);

  const updateStatus = (id: string, status: Inquiry['status']) => {
    const updated = inquiries.map(i => i.id === id ? { ...i, status } : i);
    setInquiries(updated);
    localStorage.setItem('inquiries', JSON.stringify(updated));
  };

  const deleteInquiry = (id: string) => {
    if (window.confirm('האם אתה בטוח שברצונך למחוק פנייה זו?')) {
      const updated = inquiries.filter(i => i.id !== id);
      setInquiries(updated);
      localStorage.setItem('inquiries', JSON.stringify(updated));
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row items-center justify-between mb-12 gap-4">
        <div>
          <h1 className="text-4xl font-bold serif">לוח בקרה - עו"ד דביר אייזן</h1>
          <p className="text-slate-500 mt-1">ניהול פניות ויומן פגישות משרד</p>
        </div>
        <div className="flex gap-4">
          <div className="bg-white px-6 py-3 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-3">
             <span className="w-3 h-3 bg-amber-500 rounded-full animate-pulse"></span>
             <span className="font-bold text-slate-700">{inquiries.filter(i => i.status === 'new').length} פניות חדשות</span>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Sidebar: Calendar & Sharing */}
        <div className="space-y-8">
          <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-xl border border-slate-800">
             <h3 className="text-lg font-bold mb-4 flex items-center gap-2 text-amber-500">
               📲 שיתוף מהיר עם לקוחות
             </h3>
             <p className="text-sm text-slate-400 mb-6">הצג ללקוח את ה-QR כדי שיוכל להתקין את האתר כאפליקציה במסך הבית שלו.</p>
             <div className="bg-white p-4 rounded-xl flex flex-col items-center justify-center border-4 border-amber-500 shadow-inner">
                <div className="w-40 h-40 bg-slate-100 flex items-center justify-center relative rounded-lg">
                  <div className="grid grid-cols-4 gap-2 opacity-20">
                    {Array.from({length: 16}).map((_, i) => <div key={i} className="w-6 h-6 bg-black"></div>)}
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="bg-slate-900 text-amber-500 px-3 py-1 rounded font-bold text-lg border border-amber-500 shadow-lg">QR</span>
                  </div>
                </div>
                <p className="mt-4 text-slate-900 text-xs font-bold tracking-widest uppercase">SCAN TO CONNECT</p>
             </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
            <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
              <span className="text-amber-500">📅</span> פגישות קרובות
            </h3>
            <div className="space-y-3">
              {appointments.length === 0 ? (
                <div className="text-center py-8 text-slate-400 italic">אין פגישות ביומן</div>
              ) : (
                appointments.map(app => (
                  <div key={app.id} className="p-4 bg-slate-50 rounded-xl border-r-4 border-amber-500">
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-bold text-slate-900">{app.clientName}</span>
                      <span className="text-[10px] bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-mono">{app.time}</span>
                    </div>
                    <p className="text-xs text-slate-600">{app.date} • {app.type}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Main Feed: Inquiries */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex gap-4">
            <button 
              onClick={() => setFilter('all')}
              className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${filter === 'all' ? 'bg-slate-900 text-white' : 'bg-white text-slate-600 border border-slate-200'}`}
            >
              כל הפניות ({inquiries.length})
            </button>
            <button 
              onClick={() => setFilter('new')}
              className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${filter === 'new' ? 'bg-amber-500 text-white' : 'bg-white text-slate-600 border border-slate-200'}`}
            >
              חדשות ({inquiries.filter(i => i.status === 'new').length})
            </button>
          </div>

          <div className="space-y-4">
            {inquiries
              .filter(i => filter === 'all' || i.status === 'new')
              .map(inq => {
                const ai = inq.aiAnalysis ? JSON.parse(inq.aiAnalysis) : null;
                return (
                  <div key={inq.id} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 relative group">
                    <button 
                      onClick={() => deleteInquiry(inq.id)}
                      className="absolute top-4 left-4 text-slate-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      🗑️
                    </button>
                    <div className="flex flex-col md:flex-row justify-between items-start gap-4 mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-amber-500 text-white rounded-full flex items-center justify-center font-bold">
                          {inq.name.charAt(0)}
                        </div>
                        <div>
                          <h4 className="font-bold text-lg text-slate-900">{inq.name}</h4>
                          <p className="text-sm text-slate-500">{inq.phone} • {inq.email}</p>
                        </div>
                      </div>
                      <select 
                        value={inq.status}
                        onChange={(e) => updateStatus(inq.id, e.target.value as any)}
                        className={`px-3 py-1 rounded-lg text-xs font-bold border ${
                          inq.status === 'new' ? 'bg-amber-50 text-amber-700' : 
                          inq.status === 'contacted' ? 'bg-blue-50 text-blue-700' : 'bg-green-50 text-green-700'
                        }`}
                      >
                        <option value="new">חדש</option>
                        <option value="contacted">בטיפול</option>
                        <option value="resolved">טופל</option>
                      </select>
                    </div>
                    
                    <div className="bg-slate-50 p-4 rounded-xl mb-4 border-r-2 border-slate-200 italic">
                      "{inq.message}"
                    </div>

                    {ai && (
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        <div className="bg-amber-50/50 p-3 rounded-lg border border-amber-100">
                          <span className="text-[10px] font-bold text-amber-800 uppercase block mb-1">ניתוח AI</span>
                          <p className="text-xs text-amber-900 leading-snug">{ai.summary}</p>
                        </div>
                        <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                          <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">תחום</span>
                          <p className="text-xs text-slate-900 font-bold">{ai.category}</p>
                        </div>
                        <div className="bg-rose-50 p-3 rounded-lg border border-rose-100">
                          <span className="text-[10px] font-bold text-rose-800 uppercase block mb-1">דחיפות</span>
                          <p className="text-xs text-rose-900 font-bold">{ai.urgency}</p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            
            {inquiries.length === 0 && (
              <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-slate-100">
                <p className="text-slate-400">אין פניות להצגה</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
