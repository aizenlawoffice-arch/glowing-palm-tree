
import React, { useState } from 'react';

interface FAQItem {
  question: string;
  answer: string;
}

const FAQ: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const faqData: FAQItem[] = [
    {
      question: "מה עלי לעשות מיד לאחר מעורבות בתאונת דרכים?",
      answer: "ראשית, יש להחליף פרטים עם המעורבים ולצלם את מקום התאונה והנזקים. שנית, חשוב מאוד לפנות לקבלת טיפול רפואי ראשוני גם אם אינכם חשים בכאב מיידי. שלישית, צרו קשר עם משרדנו לפני מסירת גרסה מפורטת לחברת הביטוח כדי להבטיח את זכויותיכם לקבלת פיצוי מקסימלי."
    },
    {
      question: "כיצד נקבע גובה הפיצוי בתביעת נזקי גוף?",
      answer: "גובה הפיצוי נקבע לפי מספר פרמטרים: שיעור הנכות הרפואית והתפקודית, גיל הנפגע, הפסדי שכר לעבר ולעתיד, הוצאות רפואיות, עזרת צד ג' ורכיב של 'כאב וסבל'. משרדנו נעזר במומחים רפואיים מובילים כדי להציג את התמונה המלאה לבית המשפט."
    },
    {
      question: "האם כדאי לייצג את עצמי בוועדה רפואית של ביטוח לאומי?",
      answer: "מומלץ מאוד שלא. הוועדות הרפואיות הן אירוע משפטי-רפואי מורכב. נוכחות של עורך דין מנוסה שמכיר את ספר הליקויים ואת דרכי הפעולה של הוועדות מעלה משמעותית את הסיכויים לקבלת אחוזי נכות ריאליים וקצבאות התואמות את מצבכם."
    },
    {
      question: "מהו שכר הטרחה בתביעות נזיקין?",
      answer: "ברוב תביעות הנזיקין, ובפרט בתאונות דרכים (חוק הפלת\"ד), שכר הטרחה מבוסס על אחוזים מהסכום שיתקבל בסוף ההליך. המשמעות היא שהאינטרס של המשרד זהה לחלוטין לאינטרס שלכם - להשיג את הפיצוי הגבוה ביותר במינימום זמן."
    },
    {
      question: "כמה זמן נמשך הליך משפטי בתחום הביטוח?",
      answer: "משך ההליך משתנה בהתאם למורכבות התיק. תביעות מול חברות ביטוח יכולות להסתיים בפשרה תוך מספר חודשים, או להימשך שנתיים-שלוש אם התיק מגיע לדיוני הוכחות בבית המשפט. הניסיון שלנו בליטיגציה מאפשר לנו לקצר תהליכים וללחוץ על חברות הביטוח להגיע להסדרים הוגנים מהר יותר."
    }
  ];

  return (
    <section id="faq" className="py-24 bg-slate-50">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold serif mb-4">שאלות ותשובות נפוצות</h2>
          <p className="text-slate-600">ריכזנו עבורכם מענה לשאלות שמעסיקות את רוב לקוחותינו בתחילת הדרך</p>
          <div className="w-24 h-1 bg-amber-500 mx-auto mt-4"></div>
        </div>

        <div className="space-y-4">
          {faqData.map((item, index) => (
            <div 
              key={index} 
              className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden transition-all hover:border-amber-200"
            >
              <button 
                onClick={() => setActiveIndex(activeIndex === index ? null : index)}
                className="w-full px-6 py-5 text-right flex items-center justify-between hover:bg-slate-50 transition-colors"
              >
                <span className="font-bold text-lg text-slate-900">{item.question}</span>
                <span className={`text-2xl text-amber-500 transform transition-transform ${activeIndex === index ? 'rotate-180' : ''}`}>
                  ▾
                </span>
              </button>
              <div 
                className={`px-6 transition-all duration-300 ease-in-out ${activeIndex === index ? 'max-h-96 py-5 border-t border-slate-100 opacity-100' : 'max-h-0 opacity-0 overflow-hidden'}`}
              >
                <p className="text-slate-700 leading-relaxed text-lg">
                  {item.answer}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center bg-amber-500/10 p-8 rounded-2xl border border-amber-500/20">
          <h3 className="text-xl font-bold mb-2">יש לכם שאלה ספציפית למקרה שלכם?</h3>
          <p className="text-slate-700 mb-6">עו"ד דביר אייזן זמין לייעוץ ראשוני ללא התחייבות.</p>
          <button 
            onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-slate-900 text-white px-8 py-3 rounded-full font-bold hover:bg-slate-800 transition-all shadow-lg"
          >
            פנו אלינו עכשיו
          </button>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
